Checkout & Payment Integration Readiness

Website-facing copy is English. No live third-party credentials are embedded. The locked brand identity remains unchanged.
