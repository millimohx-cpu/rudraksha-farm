Production Deployment Checklist

Website-facing copy is English. No live credentials are embedded. WhatsApp remains pending until the business device/account is available.
