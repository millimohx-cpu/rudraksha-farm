# V10 API Contract

POST /api/orders — validate input, recalculate totals/shipping server-side, create pending order.
GET /api/orders/:id — authenticated customer/admin access.
POST /api/orders/:id/payment — verify gateway payment server-side before marking paid.
PATCH /api/orders/:id/status — admin-only status changes.

Order flow: pending -> paid -> confirmed -> dispatched -> delivered; cancellation/refund paths handled server-side.

Security: payment/database secrets server-side only; authentication on admin routes; validation/sanitization; rate limiting; audit logging.
