# V78 — Shipping Calculation Engine

Organize shipping calculation so the current ₹101 / ₹1,999+ rule can later be combined with pincode, courier and weight-based rules.

Pending business details remain placeholders. No missing credential, certification, lab result, payment key, database secret or WhatsApp credential is invented or embedded.
