# V50 — Product Comparison & Pack Selection

Add a clearer pack-selection experience for 500 ml, 1 kg and 2.5 kg, with consistent pricing and product information.

This version remains a production frontend foundation. Live payment, backend, email and WhatsApp credentials are not embedded in the website.
