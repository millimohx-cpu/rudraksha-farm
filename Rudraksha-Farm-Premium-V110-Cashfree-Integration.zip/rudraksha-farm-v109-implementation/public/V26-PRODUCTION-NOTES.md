Order Confirmation & Notifications

Website-facing copy is English. Live third-party credentials are not embedded. WhatsApp remains pending until the business device/account is available.
