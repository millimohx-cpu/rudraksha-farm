# V95 — Order Reference System

Standardize the customer-facing order reference format and prepare it for future database-generated unique IDs.

Pending business details remain placeholders. No missing payment key, lab result, certification, personal credential or WhatsApp credential is invented.
