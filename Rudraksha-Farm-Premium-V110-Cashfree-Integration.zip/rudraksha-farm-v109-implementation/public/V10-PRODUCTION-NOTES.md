# RUDRAKSHA FARM — V10

V10 adds the documented production backend foundation: database schema, server-side order/payment API contract, inventory fields, admin status flow, and secure environment-variable placeholders.

Live services are intentionally NOT fabricated. A real database, payment gateway, hosting, and WhatsApp Business credentials still need to be connected.

Brand lock:
RUDRAKSHA
The Soul of Tradition
मारवाड़ का शुद्ध घी

Founder spelling: Dhananjay.
Do not publish bank account details. Do not claim organic certification or lab testing without documentary support.
