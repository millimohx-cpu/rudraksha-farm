# RUDRAKSHA FARM — V8 Production Notes

## Brand identity locked
RUDRAKSHA
The Soul of Tradition
मारवाड़ का शुद्ध घी

## V8 additions
- Product detail modal for each pack.
- Local order desk preview.
- CSV export of local order records.
- Clear separation between browser UI and future secure backend integrations.
- Payment, database, admin authentication and WhatsApp remain external integration steps.
- No bank credentials, API secrets or payment keys are included.
- Lab-tested / organic claims remain disabled until supporting documentation is supplied.

## Launch architecture
Customer browser -> Secure backend/API -> Payment gateway -> Order database -> Fulfilment/notifications.
WhatsApp should be connected through an approved business integration when the device/account is available; do not place secret credentials in index.html.
