# RUDRAKSHA FARM — V9 Production Notes

## V9 focus
- Production-ready frontend foundation retained from V8.
- Versioned order storage contract (`rudraksha_v9_orders`).
- Unique order ID format: RF-YYYYMMDD-XXXXXX.
- Order lifecycle fields: payment status and WhatsApp status.
- CSV export foundation for locally stored orders.
- No live payment credentials or WhatsApp credentials are embedded.
- Backend/API/payment gateway remain deployment integrations, not fabricated as live services.

## Still required before live launch
1. Choose hosting + backend runtime.
2. Provision a real database.
3. Connect a payment gateway using server-side secrets.
4. Configure transactional email/SMS if desired.
5. Connect WhatsApp when the business device/account is available.
6. Add final legal policy copy.
7. Add actual label/product photography when available.
8. Add lab report only after the report is received.

## Brand lock
RUDRAKSHA
The Soul of Tradition
मारवाड़ का शुद्ध घी

Founder spelling: Dhananjay.
Do not expose bank account details publicly.
Do not claim organic certification or lab testing unless documentary support is available.
