V16 website-facing section is English. Brand identity remains unchanged; the Hindi tagline 'मारवाड़ का शुद्ध घी' remains only as the locked brand identity.
